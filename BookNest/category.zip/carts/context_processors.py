from .models import Cart, CartItem
from django.core.exceptions import ObjectDoesNotExist

def counter(request):
    cart_count = 0
    try:
        cart = Cart.objects.get(cart_id=request.session.session_key)
        cart_items = CartItem.objects.filter(cart=cart, is_active=True)
        for item in cart_items:
            cart_count += item.quantity
    except ObjectDoesNotExist:
        cart_count = 0
    return dict(cart_count=cart_count)
