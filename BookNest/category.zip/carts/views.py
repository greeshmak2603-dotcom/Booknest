from django.shortcuts import render, redirect, get_object_or_404
from store.models import Product, Variation
from .models import Cart, CartItem
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from accounts.models import UserProfile  # adjust app name if different

def _cart_id(request):
    cart = request.session.session_key
    if not cart:
        cart = request.session.create()
    return cart


@login_required(login_url='login')
def add_cart(request, product_id):
    current_user = request.user
    product = Product.objects.get(id=product_id)  # get the product

    # 🔐 Only authenticated users can reach here
    product_variation = []

    if request.method == 'POST':
        for item in request.POST:
            key = item
            value = request.POST[key]

            try:
                variation = Variation.objects.get(
                    product=product,
                    variation_category__iexact=key,
                    variation_value__iexact=value
                )
                product_variation.append(variation)
            except:
                pass

    is_cart_item_exists = CartItem.objects.filter(product=product, user=current_user).exists()

    if is_cart_item_exists:
        cart_item = CartItem.objects.filter(product=product, user=current_user)
        ex_var_list = []
        id = []
        for item in cart_item:
            existing_variation = item.variations.all()
            ex_var_list.append(list(existing_variation))
            id.append(item.id)

        if product_variation in ex_var_list:
            index = ex_var_list.index(product_variation)
            item_id = id[index]
            item = CartItem.objects.get(product=product, id=item_id)
            item.quantity += 1
            item.save()
        else:
            item = CartItem.objects.create(product=product, quantity=1, user=current_user)
            if len(product_variation) > 0:
                item.variations.clear()
                item.variations.add(*product_variation)
            item.save()
    else:
        cart_item = CartItem.objects.create(
            product=product,
            quantity=1,
            user=current_user,
        )
        if len(product_variation) > 0:
            cart_item.variations.clear()
            cart_item.variations.add(*product_variation)
        cart_item.save()

    return redirect('cart')


@login_required(login_url='login')
def remove_cart(request, product_id, cart_item_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item = get_object_or_404(CartItem, product=product, user=request.user, id=cart_item_id)

    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
    else:
        cart_item.delete()

    return redirect('cart')


@login_required(login_url='login')
def remove_cart_item(request, product_id, cart_item_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item = get_object_or_404(CartItem, product=product, user=request.user, id=cart_item_id)
    cart_item.delete()
    return redirect('cart')


@login_required(login_url='login')
def cart(request, total=0, quantity=0, cart_items=None):
    tax = 0
    grand_total = 0

    cart_items = CartItem.objects.filter(user=request.user, is_active=True)

    for cart_item in cart_items:
        total += (cart_item.product.price * cart_item.quantity)
        quantity += cart_item.quantity

    tax = (2 * total) / 100
    grand_total = total + tax

    context = {
        'total': total,
        'quantity': quantity,
        'cart_items': cart_items,
        'tax': tax,
        'grand_total': grand_total,
    }

    return render(request, 'store/cart.html', context)


@login_required(login_url='login')
def checkout(request, total=0, quantity=0, cart_items=None):
    tax = 0
    grand_total = 0
    subtotal = 0   # 👈 add this

    cart_items = CartItem.objects.filter(user=request.user, is_active=True)

    for cart_item in cart_items:
        subtotal += cart_item.product.price * cart_item.quantity
        quantity += cart_item.quantity

    tax = (2 * subtotal) / 100
    grand_total = subtotal + tax

    userprofile = UserProfile.objects.get(user=request.user)

    context = {
        'subtotal': subtotal,   # 👈 pass this
        'total': subtotal,      # optional (if you use total elsewhere)
        'quantity': quantity,
        'cart_items': cart_items,
        'tax': tax,
        'grand_total': grand_total,
        'userprofile': userprofile,
    }

    return render(request, 'store/checkout.html', context)
