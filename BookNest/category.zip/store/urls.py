from django.urls import path
from . import views

urlpatterns = [
    path('', views.store, name='store'),

    # Category filtering
    path('category/<slug:category_slug>/', views.store, name='products_by_category'),

    # Subcategory filtering
    path('category/<slug:category_slug>/sub/<slug:sub_slug>/', views.store, name='products_by_subcategory'),

    # Product detail
    path('category/<slug:category_slug>/<slug:product_slug>/', views.product_detail, name='product_detail'),

    path('search/', views.search, name='search'),
    path('submit_review/<int:product_id>/', views.submit_review, name='submit_review'),

    # 🔥 Trending page
    path('trending/', views.trending_products, name='trending_products'),

    path('bestseller/', views.best_products, name='best_products'),

    # path('', views.home, name='home'),         
   # store/urls.py
path('about-us/', views.about_us, name='about_us'),
 path('career/', views.career, name='career'), 

 path('contact/', views.contact, name='contact'), 
 path('privacy/', views.privacy, name='privacy'), 
path('term/', views.term, name='term'), 
path('secure/', views.secure, name='secure'),
path('copyright/', views.copyright, name='copyright'),

]
