from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, ReviewRating, ProductGallery
from category.models import Category, SubCategory
from carts.models import CartItem
from django.db.models import Q
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import HttpResponse
from .forms import ReviewForm
from django.contrib import messages
from orders.models import OrderProduct
from django.db.models import Prefetch


def store(request, category_slug=None, sub_slug=None):
    products = Product.objects.filter(is_available=True)

    if category_slug:
        category = get_object_or_404(Category, slug=category_slug, is_active=True)
        products = products.filter(category=category)

        if sub_slug:
            subcategory = get_object_or_404(SubCategory, slug=sub_slug, category=category, is_active=True)
            products = products.filter(subcategory=subcategory)

    paginator = Paginator(products, 10)
    page = request.GET.get('page')
    paged_products = paginator.get_page(page)

    categories = Category.objects.filter(is_active=True).prefetch_related(
        Prefetch('subcategories', queryset=SubCategory.objects.filter(is_active=True))
    )

    context = {
        'products': paged_products,
        'product_count': products.count(),
        'categories': categories,   # 🔥 THIS makes categories show in template
    }

    return render(request, 'store/store.html', context)


def product_detail(request, category_slug, product_slug):
    single_product = get_object_or_404(Product, category__slug=category_slug, slug=product_slug)

    # Check if product is in cart (ONLY for logged-in users)
    if request.user.is_authenticated:
        in_cart = CartItem.objects.filter(user=request.user, product=single_product).exists()
        orderproduct = OrderProduct.objects.filter(user=request.user, product_id=single_product.id).exists()
    else:
        in_cart = False
        orderproduct = None

    # Reviews
    reviews = ReviewRating.objects.filter(product_id=single_product.id, status=True)

    # Product gallery
    product_gallery = ProductGallery.objects.filter(product_id=single_product.id)

    context = {
        'single_product': single_product,
        'in_cart': in_cart,
        'orderproduct': orderproduct,
        'reviews': reviews,
        'product_gallery': product_gallery,
    }
    return render(request, 'store/product_detail.html', context)


def search(request):
    products = Product.objects.none()
    product_count = 0

    if 'keyword' in request.GET:
        keyword = request.GET['keyword']
        if keyword:
            products = Product.objects.order_by('-created_date').filter(
                Q(description__icontains=keyword) |
                Q(product_name__icontains=keyword)
            )
            product_count = products.count()

    context = {
        'products': products,
        'product_count': product_count,
    }
    return render(request, 'store/store.html', context)


def submit_review(request, product_id):
    url = request.META.get('HTTP_REFERER')

    if not request.user.is_authenticated:
        messages.warning(request, "Please login to submit a review.")
        return redirect('login')

    if request.method == 'POST':
        try:
            reviews = ReviewRating.objects.get(user__id=request.user.id, product__id=product_id)
            form = ReviewForm(request.POST, instance=reviews)
            if form.is_valid():
                form.save()
                messages.success(request, 'Thank you! Your review has been updated.')
                return redirect(url)
        except ReviewRating.DoesNotExist:
            form = ReviewForm(request.POST)
            if form.is_valid():
                data = ReviewRating()
                data.subject = form.cleaned_data['subject']
                data.rating = form.cleaned_data['rating']
                data.review = form.cleaned_data['review']
                data.ip = request.META.get('REMOTE_ADDR')
                data.product_id = product_id
                data.user_id = request.user.id
                data.save()
                messages.success(request, 'Thank you! Your review has been submitted.')
                return redirect(url)
            

def trending_products(request):
    products = Product.objects.filter(
        product_status='now_trending',
        is_available=True
    )

    paginator = Paginator(products, 10)
    page = request.GET.get('page')
    paged_products = paginator.get_page(page)

    product_count = products.count()

    context = {
        'products': paged_products,
        'product_count': product_count,
    }
    return render(request, 'store/store.html', context)

def best_products(request):
    products = Product.objects.filter(
        product_status='best_seller',
        is_available=True
    )

    paginator = Paginator(products, 10)
    page = request.GET.get('page')
    paged_products = paginator.get_page(page)

    product_count = products.count()

    context = {
        'products': paged_products,
        'product_count': product_count,
    }
    return render(request, 'store/store.html', context)

def about_us(request):
    return render(request, 'store/about_us.html')


def home(request):
    return render(request, 'home.html')  
def career(request):
    return render(request, 'store/career.html')

def contact(request):
    return render(request, 'store/contact.html')

def privacy(request):
    return render(request, 'store/privacy.html')

def term(request):
    return render(request, 'store/term.html')


def secure(request):
    return render(request, 'store/secure.html')

def copyright(request):
    return render(request, 'store/copyright.html')



