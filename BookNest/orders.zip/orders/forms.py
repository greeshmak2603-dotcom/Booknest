from django import forms
from .models import Order
import re

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'address_line_1',
            'address_line_2',
            'city',
            'state',
            'country',
            'order_note',
        ]

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if not phone or not phone.isdigit() or len(phone) != 10:
            raise forms.ValidationError("Phone must be 10 digits")
        return phone

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if not email or '@' not in email:
            raise forms.ValidationError("Enter valid email")
        return email